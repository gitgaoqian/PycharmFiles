function getValue()
{
	var arr=document.form1.check;
	alert(arr[0].value);
}